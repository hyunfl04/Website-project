require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const carRoutes = require('./routes/cars');
const authRoutes = require('./routes/auth');
const cartRoutes = require('./routes/cart');

const app = express();
const PORT = process.env.PORT || 5173;

// Lấy URI từ biến môi trường
const MONGO_URI = process.env.MONGO_URI;

// Middleware
// Cho phép frontend ở cổng 5173 truy cập
app.use(cors({ 
    origin: ['http://127.0.0.1:5500', 'http://localhost:5173'],
    methods: ['GET', 'POST', 'PUT', 'DELETE'],
    credentials: true,
    optionsSuccessStatus: 204
 })); 
app.use(express.json());

// Kết nối MongoDB
mongoose.connect(MONGO_URI)
    .then(() => {
        console.log('Connected to MongoDB Atlas');
        // Khởi tạo dữ liệu admin mặc định nếu chưa có
        initializeAdmin(); 
    })
    .catch(err => {
        console.error('Could not connect to MongoDB:', err);
        // Tắt ứng dụng nếu không thể kết nối DB
        process.exit(1); 
    });

// Hàm khởi tạo Admin (Giữ nguyên logic cũ)
const User = require('./models/User');
async function initializeAdmin() {
    const admin = await User.findOne({ username: '123' });
    if (!admin) {
        await User.create({
            username: '123',
            password: '123456', 
            fullName: 'System Admin',
            isAdmin: true
        });
        console.log('Default Admin (123/123456) created or confirmed.');
    }
}

// Routes
app.use('/api/cars', carRoutes);
app.use('/api/auth', authRoutes);
app.use('/api/cart', cartRoutes);

// Khởi chạy server
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});