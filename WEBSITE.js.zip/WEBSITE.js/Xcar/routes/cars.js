const express = require('express');
const router = express.Router();
const Car = require('../models/Car');

// Middleware xác thực admin (rất cơ bản, chỉ kiểm tra user ID)
const adminAuth = (req, res, next) => {
    // Logic frontend quy định: Admin là user '123'
    // Trong thực tế, bạn sẽ dùng JWT hoặc Session
    if (req.headers['x-user-id'] === '123') {
        next();
    } else {
        res.status(403).json({ message: 'Forbidden: Admin access required' });
    }
};

// [GET] /api/cars - Lấy tất cả xe
router.get('/', async (req, res) => {
    try {
        const cars = await Car.find().sort({ price: -1 });
        res.json(cars);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

// [GET] /api/cars/affordability - Tìm xe phù hợp với ngân sách
router.get('/affordability', async (req, res) => {
    const { salary } = req.query;
    if (!salary || isNaN(salary)) {
        return res.status(400).json({ message: 'Invalid salary input' });
    }
    
    const maxPrice = parseFloat(salary) * 24; // Mức giá tối đa = lương * 24 tháng (2 năm)

    try {
        const bestCar = await Car.findOne({ price: { $lte: maxPrice } })
                                  .sort({ price: -1 })
                                  .limit(1);
        
        if (bestCar) {
            const months = Math.ceil(bestCar.price / parseFloat(salary));
            res.json({ 
                car: bestCar, 
                months,
                message: "Recommendation found"
            });
        } else {
            const minPrice = await Car.findOne().sort({ price: 1 });
            res.json({ 
                car: null, 
                minPrice: minPrice ? minPrice.price : 0,
                message: "No car found within budget" 
            });
        }
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

// [POST] /api/cars - Thêm xe mới (Admin Only)
router.post('/', adminAuth, async (req, res) => {
    const carData = { ...req.body, id: 'c_' + Date.now() }; // Tạo id mới
    const newCar = new Car(carData);

    try {
        const savedCar = await newCar.save();
        res.status(201).json(savedCar);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

// [PUT] /api/cars/:id - Cập nhật xe (Admin Only)
router.put('/:id', adminAuth, async (req, res) => {
    try {
        const updatedCar = await Car.findOneAndUpdate({ id: req.params.id }, req.body, { new: true });
        if (!updatedCar) return res.status(404).json({ message: 'Car not found' });
        res.json(updatedCar);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

// [DELETE] /api/cars/:id - Xóa xe (Admin Only)
router.delete('/:id', adminAuth, async (req, res) => {
    try {
        const result = await Car.deleteOne({ id: req.params.id });
        if (result.deletedCount === 0) return res.status(404).json({ message: 'Car not found' });
        res.json({ message: 'Car deleted' });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

module.exports = router;