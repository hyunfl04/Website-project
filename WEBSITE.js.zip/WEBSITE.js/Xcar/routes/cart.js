// File: routes/cart.js
const express = require('express');
const router = express.Router();
const mongoose = require('mongoose');

// Models
const Cart = require('../models/Cart');
const User = require('../models/User'); // Cần để giải quyết username thành _id
const Car = require('../models/Car');   // Cần để kiểm tra carId

// Middleware đơn giản để xác định User ID từ username
// (Vì Frontend hiện tại gửi username trong header 'X-User-Id')
async function resolveUser(req, res, next) {
    const username = req.header('X-User-Id'); 
    
    if (!username) {
        return res.status(401).json({ message: "Authentication required (Missing X-User-Id header)." });
    }

    try {
        const user = await User.findOne({ username });
        if (!user) {
            return res.status(401).json({ message: "User not found." });
        }
        // Gắn _id của người dùng vào request để sử dụng trong các routes sau
        req.userId = user._id; 
        next();
    } catch (error) {
        console.error("User resolution error:", error);
        res.status(500).json({ message: "Server error during authentication." });
    }
}

// Áp dụng middleware cho tất cả các tuyến đường của Cart
router.use(resolveUser);

// ----------------------------------------------------
// [GET] /api/cart - Tải giỏ hàng của người dùng
// ----------------------------------------------------
router.get('/', async (req, res) => {
    try {
        // Tìm giỏ hàng và populate chi tiết xe
        const cart = await Cart.findOne({ userId: req.userId })
            .populate({
                path: 'items.carId',
                model: Car,
                select: 'name brand price coverImage' // Chỉ lấy các trường cần thiết
            });

        if (!cart) {
            // Trả về giỏ hàng rỗng nếu không tìm thấy
            return res.json({ items: [] });
        }

        // Chuyển đổi dữ liệu để Frontend dễ xử lý hơn
        const simplifiedItems = cart.items.map(item => ({
            car: {
                _id: item.carId._id,
                brand: item.carId.brand,
                name: item.carId.name,
                price: item.carId.price,
                coverImage: item.carId.coverImage,
            },
            quantity: item.quantity
        }));

        res.json({ items: simplifiedItems });
    } catch (error) {
        console.error("Error loading cart:", error);
        res.status(500).json({ message: "Failed to load cart." });
    }
});


// ----------------------------------------------------
// [POST] /api/cart - Thêm hoặc Cập nhật sản phẩm
// ----------------------------------------------------
router.post('/', async (req, res) => {
    const { carId, quantity = 1 } = req.body;

    if (!carId || !mongoose.Types.ObjectId.isValid(carId)) {
        return res.status(400).json({ message: "Invalid Car ID." });
    }

    try {
        let cart = await Cart.findOne({ userId: req.userId });

        // 1. Nếu chưa có giỏ hàng, tạo mới
        if (!cart) {
            cart = new Cart({
                userId: req.userId,
                items: [{ carId, quantity }]
            });
        } else {
            // 2. Nếu đã có giỏ hàng, kiểm tra item đã tồn tại chưa
            const itemIndex = cart.items.findIndex(item => item.carId.toString() === carId);

            if (itemIndex > -1) {
                // Sản phẩm đã tồn tại -> Cập nhật số lượng
                cart.items[itemIndex].quantity += quantity;
            } else {
                // Sản phẩm chưa tồn tại -> Thêm mới
                cart.items.push({ carId, quantity });
            }
        }

        await cart.save();
        res.status(200).json({ message: "Item added/updated in cart.", cart });

    } catch (error) {
        console.error("Error adding to cart:", error);
        res.status(500).json({ message: "Failed to add item to cart." });
    }
});


// ----------------------------------------------------
// [DELETE] /api/cart/:carId - Xóa sản phẩm khỏi giỏ hàng
// ----------------------------------------------------
router.delete('/:carId', async (req, res) => {
    const { carId } = req.params;

    if (!mongoose.Types.ObjectId.isValid(carId)) {
        return res.status(400).json({ message: "Invalid Car ID." });
    }

    try {
        const cart = await Cart.findOne({ userId: req.userId });

        if (!cart) {
            return res.status(404).json({ message: "Cart not found." });
        }

        // Lọc bỏ sản phẩm có carId trùng khớp
        const initialLength = cart.items.length;
        cart.items = cart.items.filter(item => item.carId.toString() !== carId);
        
        if (cart.items.length === initialLength) {
             return res.status(404).json({ message: "Car not found in cart." });
        }

        await cart.save();
        res.status(200).json({ message: "Item removed from cart." });

    } catch (error) {
        console.error("Error removing item from cart:", error);
        res.status(500).json({ message: "Failed to remove item from cart." });
    }
});


module.exports = router;