const express = require('express');
const router = express.Router();
const User = require('../models/User');

// [POST] /api/auth/register - Đăng ký
router.post('/register', async (req, res) => {
    const { username, password, fullName, dob } = req.body;

    if (!username || !password) {
        return res.status(400).json({ message: 'Username and Password are required' });
    }

    try {
        // Kiểm tra xem đây có phải là tài khoản admin mặc định không
        const isAdmin = (username === '123' && password === '123456');

        const newUser = new User({
            username,
            password, // *LƯU Ý*: Trong thực tế PHẢI hash password trước khi lưu
            fullName,
            dob,
            isAdmin
        });

        await newUser.save();
        // Trả về thông tin user (nên loại bỏ password)
        res.status(201).json({ id: newUser._id, username: newUser.username, isAdmin: newUser.isAdmin });
    } catch (err) {
        // Xử lý lỗi trùng lặp username
        if (err.code === 11000) {
            return res.status(409).json({ message: 'Username already exists' });
        }
        res.status(500).json({ message: err.message });
    }
});

// [POST] /api/auth/login - Đăng nhập
router.post('/login', async (req, res) => {
    const { username, password } = req.body;

    try {
        // 1. Kiểm tra tài khoản admin mặc định (123/123456)
        if (username === '123' && password === '123456') {
             // Đảm bảo tài khoản admin có trong DB hoặc tạo mới nếu chưa có
             let adminUser = await User.findOne({ username: '123' });
             if (!adminUser) {
                 adminUser = await User.create({ username: '123', password: '123456', isAdmin: true, fullName: 'System Admin' });
             }
            return res.json({ id: adminUser._id, username: adminUser.username, isAdmin: true });
        }

        // 2. Tìm user trong DB
        const user = await User.findOne({ username });
        if (!user) {
            return res.status(401).json({ message: 'Invalid username or password' });
        }

        // 3. So sánh password (KHÔNG AN TOÀN - chỉ để đáp ứng yêu cầu logic cơ bản)
        if (user.password !== password) {
            return res.status(401).json({ message: 'Invalid username or password' });
        }

        // Đăng nhập thành công
        res.json({ id: user._id, username: user.username, isAdmin: user.isAdmin });

    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

module.exports = router;