const express = require('express');
const router = express.Router();
const Car = require('../models/Car');

// ==========================================================
// [BỔ SUNG 1]: IMPORTS VÀ CẤU HÌNH MULTER
// ==========================================================
const multer = require('multer');
const path = require('path');
const fs = require('fs');

// Middleware xác thực Admin
const adminAuth = (req, res, next) => {
    const userId = req.header('X-User-Id');
    if (!userId || (userId !== 'admin' && userId !== '123')) {
        return res.status(403).json({ message: 'Access denied. Admin privileges required.' });
    }
    next();
};

// 1.1. Đảm bảo thư mục public/uploads tồn tại
const uploadDir = path.join(__dirname, '..', 'public', 'uploads');
if (!fs.existsSync(uploadDir)) {
    fs.mkdirSync(uploadDir, { recursive: true });
}

// 1.2. Cấu hình cách lưu trữ
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, uploadDir); 
    },
    filename: (req, file, cb) => {
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
    }
});

// 1.3. Khởi tạo Multer để xử lý 5 tệp (1 cover + 4 gallery)
const upload = multer({ storage: storage }).fields([
    { name: 'coverImage', maxCount: 1 },
    { name: 'gallery1', maxCount: 1 },
    { name: 'gallery2', maxCount: 1 },
    { name: 'gallery3', maxCount: 1 },
    { name: 'gallery4', maxCount: 1 }
]);

// ==========================================================
// Hỗ trợ xóa file vật lý trên Server
// ==========================================================
const deleteFiles = (paths) => {
    // ... (logic xóa file giữ nguyên)
    const filePaths = Array.isArray(paths) ? paths : [paths];
    filePaths.forEach(relativePath => {
        if (relativePath && relativePath.startsWith('/uploads/')) {
            const fileName = relativePath.replace('/uploads/', '');
            const filePath = path.join(uploadDir, fileName);
            fs.unlink(filePath, (err) => {
                if (err && err.code !== 'ENOENT') { 
                    console.error(`Error deleting file: ${filePath}`, err);
                } else if (!err) {
                    console.log(`Successfully deleted old file: ${fileName}`);
                }
            });
        }
    });
};

// ==========================================================
// [GET] /api/cars - Lấy tất cả xe
// ==========================================================
router.get('/', async (req, res) => {
    try {
        const cars = await Car.find();
        res.json(cars);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});


// ==========================================================
// [POST] /api/cars - Thêm xe mới (Admin Only)
// ==========================================================
router.post('/', adminAuth, upload, async (req, res) => {
    const files = req.files;
    const { brand, name, price, description, specs } = req.body;
    
    let parsedSpecs = {};
    if (specs) {
        try {
            parsedSpecs = JSON.parse(specs);
        } catch (e) {
            console.error("Warning: Error parsing specs JSON. Proceeding with empty specs.", e);
            parsedSpecs = {}; 
        }
    }

    // ⚡️ ĐOẠN CODE LẤY ĐƯỜNG DẪN FILE TRỰC TIẾP
    const coverFile = files['coverImage']?.[0]; // Lấy trực tiếp file đầu tiên
    let coverImagePath = coverFile 
        ? `/uploads/${coverFile.filename}` // Xây dựng đường dẫn ngay lập tức
        : 'https://via.placeholder.com/800';

    let galleryImages = [];
    // Lặp qua 4 trường gallery, lấy tên file trực tiếp
    for (let i = 1; i <= 4; i++) {
        const file = files[`gallery${i}`]?.[0]; 
        if (file) {
            galleryImages.push(`/uploads/${file.filename}`);
        }
    }
    // ⚡️ KẾT THÚC ĐOẠN CODE LẤY ĐƯỜNG DẪN FILE TRỰC TIẾP

    try {
        const newCar = new Car({
            brand,
            name,
            price: parseFloat(price),
            description,
            coverImage: coverImagePath,
            galleryImages,
            specs: parsedSpecs
        });
        await newCar.save();
        res.status(201).json(newCar);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

// ==========================================================
// [PUT] /api/cars/:id - Cập nhật xe (Admin Only)
// ==========================================================
router.put('/:id', adminAuth, upload, async (req, res) => {
    const carId = req.params.id;
    const files = req.files;
    const { brand, name, price, description, specs } = req.body;

    let updateData = {};
    
    if (brand) updateData.brand = brand;
    if (name) updateData.name = name;
    if (price) updateData.price = parseFloat(price); 
    if (description) updateData.description = description;

    if (specs) {
        try {
            updateData.specs = JSON.parse(specs); 
        } catch (e) {
            console.error("Warning: Error parsing specs JSON. Ignoring specs update.", e);
        }
    }

    try {
        const existingCar = await Car.findById(carId);
        if (!existingCar) return res.status(404).json({ message: 'Car not found' });
        
        // ⚡️ ĐOẠN CODE LẤY ĐƯỜNG DẪN FILE TRỰC TIẾP (UPDATE)
        const coverFile = files['coverImage']?.[0]; 
        if (coverFile) {
            if (existingCar.coverImage && existingCar.coverImage !== 'https://via.placeholder.com/800') {
                deleteFiles(existingCar.coverImage);
            }
            updateData.coverImage = `/uploads/${coverFile.filename}`;
        } 

        let newGalleryUrls = [];
        for (let i = 1; i <= 4; i++) {
            const file = files[`gallery${i}`]?.[0];
            if (file) {
                newGalleryUrls.push(`/uploads/${file.filename}`);
            }
        }

        if (newGalleryUrls.length > 0) {
            deleteFiles(existingCar.galleryImages);
            updateData.galleryImages = newGalleryUrls; 
        }
        // ⚡️ KẾT THÚC ĐOẠN CODE LẤY ĐƯỜNG DẪN FILE TRỰC TIẾP (UPDATE)


        const updatedCar = await Car.findOneAndUpdate({ _id: carId }, updateData, { new: true, runValidators: true });
        res.json(updatedCar);

    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

// ==========================================================
// [DELETE] /api/cars/:id - Xóa xe (Admin Only)
// ==========================================================
router.delete('/:id', adminAuth, async (req, res) => {
    try {
        const carToDelete = await Car.findById(req.params.id);
        if (!carToDelete) return res.status(404).json({ message: 'Car not found' });

        const allFiles = [...carToDelete.galleryImages];
        if (carToDelete.coverImage && carToDelete.coverImage !== 'https://via.placeholder.com/800') {
            allFiles.push(carToDelete.coverImage);
        }
        deleteFiles(allFiles); 

        await Car.deleteOne({ _id: req.params.id }); 
        
        res.json({ message: 'Car and associated files deleted successfully' });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

// ==========================================================
// [GET] /api/cars/affordability - Budget Finder
// ==========================================================
router.get('/affordability', async (req, res) => {
    const salary = parseFloat(req.query.salary);

    if (isNaN(salary) || salary <= 0) {
        return res.status(400).json({ message: 'Invalid salary input.' });
    }

    try {
        const cars = await Car.find({}).sort({ price: 1 });
        if (cars.length === 0) {
            return res.json({ message: 'No cars available yet.' });
        }

        const minPrice = cars[0].price;
        const budget = 0.3 * salary * 96; 
        
        let affordableCar = null;

        for (const car of cars) {
            if (car.price <= budget) {
                affordableCar = car;
            } else {
                break; 
            }
        }

        if (affordableCar) {
            const monthsToSave = Math.ceil(affordableCar.price / (0.3 * salary)); 
            return res.json({ car: affordableCar, months: monthsToSave });
        } else {
            return res.json({ 
                message: `The current budget limit ($${budget.toLocaleString()}) is too low. The cheapest car starts at $${minPrice.toLocaleString()}.`,
                minPrice: minPrice
            });
        }

    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

module.exports = router;