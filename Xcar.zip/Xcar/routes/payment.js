// Ví dụ: Tạo Payment Intent (Chỉ định số tiền)
// POST /api/payment/create-payment-intent
router.post('/create-payment-intent', async (req, res) => {
    const { totalAmount } = req.body;
    try {
        const paymentIntent = await stripe.paymentIntents.create({
            amount: totalAmount * 100, // Đơn vị tính bằng cent
            currency: 'usd',
        });
        res.send({ clientSecret: paymentIntent.client_secret });
    } catch (error) {
        res.status(500).send({ error: error.message });
    }
});