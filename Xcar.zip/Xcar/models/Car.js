const mongoose = require('mongoose');

const carSchema = new mongoose.Schema({
    id: { type: String, required: true, unique: true }, // Dùng id này để khớp với logic frontend
    brand: { type: String, required: true },
    name: { type: String, required: true },
    price: { type: Number, required: true },
    description: { type: String, required: true },
    coverImage: { type: String },
    galleryImages: [{ type: String }],
    specs: {
        accel: String, // 0-100 km/h
        power: String,
        speed: String
    }
});

module.exports = mongoose.model('Car', carSchema);