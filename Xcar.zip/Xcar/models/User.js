const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
    username: { type: String, required: true, unique: true }, // Có thể là email hoặc số điện thoại
    password: { type: String, required: true }, // Trong thực tế nên hash password
    fullName: { type: String },
    dob: { type: Date },
    isAdmin: { type: Boolean, default: false } // Phân quyền admin
});

module.exports = mongoose.model('User', userSchema);