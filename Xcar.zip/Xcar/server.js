// File: server.js
require('dotenv').config();

const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');

const carRoutes = require('./routes/cars');
const authRoutes = require('./routes/auth');
const cartRoutes = require('./routes/cart');
const path = require('path');
// const multer = require('multer'); // Đã loại bỏ Multer

const app = express();
const PORT = process.env.PORT || 5173;

const MONGO_URI = process.env.MONGO_URI;

// Middleware
app.use(cors({
    origin: ['http://127.0.0.1:5500', 'http://localhost:5173'],
    methods: ['GET', 'POST', 'PUT', 'DELETE'],
    credentials: true,
    optionsSuccessStatus: 204
}));

// TĂNG GIỚI HẠN KÍCH THƯỚC BODY
app.use(express.json({ }));
app.use(express.urlencoded({  }));

// ==========================================================
// [FIX LỖI 404] PHỤC VỤ FILE ẢNH TĨNH
// Server sẽ tìm ảnh trong thư mục ./public/uploads khi URL là /uploads
// ==========================================================
app.use('/uploads', express.static(path.join(__dirname, 'public', 'uploads')));
app.use('/videos', express.static(path.join(__dirname, 'public', 'videos')));
// ==========================================================


// Routes
app.use('/api/cars', carRoutes);
app.use('/api/auth', authRoutes);
app.use('/api/cart', cartRoutes);


// Kết nối MongoDB
mongoose.connect(MONGO_URI)
    .then(() => {
        console.log('Connected to MongoDB Atlas');
        initializeAdmin();
    })
    .catch(err => {
        console.error('Could not connect to MongoDB:', err);
        process.exit(1);
    });

// Hàm khởi tạo Admin (Giữ nguyên logic cũ)
const User = require('./models/User');

async function initializeAdmin() {
    const admin = await User.findOne({ username: '123' });
    if (!admin) {
        await User.create({
            username: '123',
            password: '123', // Mật khẩu được hash tự động trong model
            role: 'admin'
        });
        console.log('Default admin user created.');
    }
}

app.listen(PORT, () => console.log(`Server running on port ${PORT}`));