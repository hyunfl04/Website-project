// src/App.jsx
import './App.css'; // Import CSS dành riêng cho component này

function App() {
  // Đường dẫn ảnh
  // Đảm bảo ảnh SF90.jpg nằm ở thư mục gốc (public/ hoặc assets/)
  const carImageSrc = 'c:\Users\PC\Downloads\novitec-ferrari-sf90-stradale-2022.jpg'; 

  const handleAddToCart = () => {
    alert('Đã thêm Ferrari SF90 Stradale vào giỏ hàng!');
  };

  return (
    <div className="App">
      <h1>X-CAR | Luxury Collection</h1>
      
      <div className="product-card">
        {/*
          SỬA LỖI 404 Ở ĐÂY:
          Sử dụng đường dẫn bắt đầu bằng '/' để đảm bảo đường dẫn tuyệt đối từ thư mục gốc
          (Ví dụ: /assets/images/SF90.jpg)
        */}
        <img 
          src={carImageSrc} 
          alt="Ferrari SF90 Stradale" 
          className="car-image"
        />
        
        <h2>Ferrari SF90 Stradale</h2>
        <p className="price">$507,000</p>
        
        <button 
          className="add-to-cart-btn" 
          onClick={handleAddToCart}
        >
          ADD TO CART
        </button>
      </div>

      {/* Bạn có thể thêm các product-card khác tương tự */}
    </div>
  );
}

export default App;